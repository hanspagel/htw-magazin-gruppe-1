In meinem Artikel beschäftige ich mich mit Chloe Wise' Ausstellung "Of false beaches and butter money".
Die Ausstellung besteht aus Rauminstallationen sowie dazugehörigen Malereien und Videos.
Wise beschäftigt sich mit dem Konsum alltäglicher Verbrauchsgüter wie Milch und
untersucht die Feminisierung dieser zugunsten der Vermarktung und des Verkaufs.
Die Ausstellung in der Pariser Almine Rech Gallery wurde von Léonard Méchineau fotografiert, der Artikel stammt von der offiziellen Museumswebsite.
Ich habe mich für diese Künstlerin entschieden, da ich ihre Arbeiten sehr schätze und mir ihre zeitgenössische Ästhetik gefällt.
Sie arbeitet mit Symbolen des Feminismus (Früchte & Milch) die uns jeden Tag auf den sozialen Medien begegnen, schafft es aber sie so sensibel und ästhetisch darzustellen, dass ich beim Anblick nicht genervt bin, sondern mich als Beobachter gerne auf sie einlasse.
Die Spiegel verstärken diesen Effekt und die Dramatik und die weichen Farbübergänge der Gemälde erinnert mich an die alten Meister.

Mit der Landing Page möchte ich den Artikel anhand des Bildes und der Kombination der Schriftelemente tonal einleiten.
Durch die Hoverbuttons wird man durch den Artikel navigiert.
Für die Slideshow habe ich eine Extraseite angelegt, da ich die Bilder für sich wirken lassen wollte.
Allgemein habe ich das Design eher reduziert gehalten um die einzelnen Elemente und besonders die Ausstellungsstücke den nötigen Raum zu geben.
